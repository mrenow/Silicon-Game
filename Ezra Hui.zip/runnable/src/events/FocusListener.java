package events;

public interface FocusListener extends HoverListener{

  void elementFocused();
  void elementUnfocused();

}




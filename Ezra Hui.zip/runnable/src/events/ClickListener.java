package events;

public interface ClickListener extends HoverListener {
	public void elementClicked();

	public void elementReleased();
}

package events;

// base interface type for all listeners
public abstract interface Listener {
}
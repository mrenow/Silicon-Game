package events;

public interface ScrollListener extends HoverListener {
	public void elementScrolled(int value);
}
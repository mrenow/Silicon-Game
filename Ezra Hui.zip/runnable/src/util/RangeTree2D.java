package util;

public class RangeTree2D <T> {
	public RangeTree2D() {

		
		
	}
	
}

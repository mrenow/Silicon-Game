package elements;
import static core.MainProgram.*;
import static util.DB.*;
public class Collection {

}
